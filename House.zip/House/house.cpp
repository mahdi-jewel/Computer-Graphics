#include <iostream>
#include <cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
using namespace std;

void display (void){
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(.8670, .0431, .0431);
    glBegin(GL_POLYGON);
    glVertex2f(.25, 1.5);
    glVertex2f(1.0, 2.0);
    glVertex2f(2.0, 2.0);
    glVertex2f(2.75, 1.5);
    glEnd();

    glColor3f(58.0, 88.0, 54.0);
    glBegin(GL_POLYGON);
    glVertex2f(0.5, 1.50);
    glVertex2f(2.5, 1.5);
    glVertex2f(2.5, 0.5);
    glVertex2f(0.5, 0.5);
    glEnd();

    glColor3f(0.0, 109.0, 176.0);
    glBegin(GL_POLYGON);
    glVertex2f(1.25, 0.50);
    glVertex2f(1.25, 1.2);
    glVertex2f(1.75, 1.2);
    glVertex2f(1.75, 0.5);
    glEnd();

    glColor3f(0.101, 0.6313, 0.3725);
    glBegin(GL_POLYGON);
    glVertex2f(0.25, 0.50);
    glVertex2f(2.75, 0.50);
    glVertex2f(2.75, 0.30);
    glVertex2f(0.25, 0.30);

    glEnd();

    glFlush();

}




void init (void) {
glClearColor(0.0, 0.0, 0.0, 0.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(-5.0, 3.0, -5.0, 3.0, -5.0, 3.0);
}

int main(int argc,char** argv){
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
glutInitWindowSize (800,700);
glutInitWindowPosition (100,100);
glutCreateWindow("Jewel");
init();
glutDisplayFunc(display);
glutMainLoop();

return 0;
}
