#include<windows.h>
#include<stdio.h>
#include<math.h>
#include <GL/glut.h>
#include<conio.h>
#include<stdlib.h>

double floorOrceil(double x)
{
    if(x<floor(x)+0.5)
        return floor(x);
    else if (x>floor(x)+0.5)
    {
        return ceil(x);
    }
}

static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.89,0.043,0.043);

    double x1=5;
    double y1=6;

    double x2=15;
    double y2=13;

    double m=(y2-y1)/(x2-x1);
    printf("Slope: %lf",m);

    if(m<1 && m>0)
    {
        double xk,yk,xk1,yk1;
        for(double i=x1; i<=x2-1; i++)
        {
            if (i==x1)
            {
                xk=x1;
                yk=y1;
            }
            xk1=xk+1;
            yk1=yk+m;

            printf("\nxk: %lf, yk:%lf",xk1,floorOrceil(yk1));
            glBegin(GL_LINES);
            glVertex2d(xk, floorOrceil(yk));
            glVertex2d(xk1, floorOrceil(yk1));
            glEnd();

            xk=xk1;
            yk=yk1;
        }
        glBegin(GL_LINES);
        glVertex2d(xk, floorOrceil(yk));
        glVertex2d(x2,y2);
        glEnd();
    }
    glFlush();
}

void init()
{
    glClearColor(1,1,1,5);
    glOrtho(-30,30,-30,30,-30,30);
}
int main()
{
    glutInitWindowSize(720,480);
    glutInitWindowPosition(50,50);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);

    glutCreateWindow("Sarwar Mahmud Milon");
    init();

    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
